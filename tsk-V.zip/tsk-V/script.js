const apiKey = "000ec3945d1281478811f552d5cf14f5";

// Search Weather by City
async function getWeather() {

    const city = document.getElementById("cityInput").value;

    if (!city) {
        alert("Please enter a city name");
        return;
    }

    const url =
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

    try {

        const response = await fetch(url);
        const data = await response.json();

        if (data.cod != 200) {
            alert("City not found!");
            return;
        }

        displayWeather(data);

    } catch (error) {

        console.error(error);
        alert("Error fetching weather data");

    }
}

// Display Weather Data
function displayWeather(data) {

    document.getElementById("city").innerText = data.name;
    document.getElementById("temp").innerText =
        Math.round(data.main.temp) + "°C";

    document.getElementById("description").innerText =
        data.weather[0].description;

    document.getElementById("humidity").innerText =
        data.main.humidity + "%";

    document.getElementById("wind").innerText =
        data.wind.speed + " km/h";

    const feelsLike = document.getElementById("feelsLike");
    if (feelsLike) {
        feelsLike.innerText =
            Math.round(data.main.feels_like) + "°C";
    }

    const pressure = document.getElementById("pressure");
    if (pressure) {
        pressure.innerText =
            data.main.pressure + " hPa";
    }

    const icon = document.getElementById("weatherIcon");
    if (icon) {
        icon.src =
            `https://openweathermap.org/img/wn/${data.weather[0].icon}@4x.png`;
    }
}
// Get Weather by Current Location
function getCurrentLocation() {

    if (!navigator.geolocation) {
        alert("Geolocation is not supported");
        return;
    }

    navigator.geolocation.getCurrentPosition(
        async (position) => {

            const lat = position.coords.latitude;
            const lon = position.coords.longitude;

            const url =
                `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;

            try {

                const response = await fetch(url);
                const data = await response.json();

                displayWeather(data);

            } catch(error){
    console.error(error);
}

        },
        () => {
            alert("Location access denied");
        }
    );
}

// Live Date & Time
function updateDateTime() {

    const now = new Date();

    document.getElementById("dateTime").innerText =
        now.toLocaleString();
}

setInterval(updateDateTime, 1000);
updateDateTime();

// Search when Enter key is pressed
document.getElementById("cityInput")
    .addEventListener("keypress", function (event) {

        if (event.key === "Enter") {
            getWeather();
        }

    });